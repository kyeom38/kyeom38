/**
 * static/js 폴더의 test.js 파일
 */

 function function1()
 {
	 alert('안녕하세요.');
 }